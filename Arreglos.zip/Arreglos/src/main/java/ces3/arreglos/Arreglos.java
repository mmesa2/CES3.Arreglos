/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ces3.arreglos;

import java.util.ArrayList;
import java.util.Random;
import java.util.stream.Collectors;

/**
 *
 * @author Acer
 */
public class Arreglos {

    public static void main(String[] args) {
        int arraySize = 30;
        int[] numbers = new int[arraySize];

        // Llenar el arreglo con números aleatorios
        for(int i = 0; i < arraySize; i++) {
            numbers[i] = random();
        }

        // Imprimir los números en el arreglo
        System.out.println("Numbers in array:");
        for(int i = 0; i < arraySize; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println(); // Imprimir nueva línea

        // Filtrar y mostrar solo los números pares
        System.out.println("Even numbers:");
        for(int i = 0; i < arraySize; i++) {
            if(numbers[i] % 2 == 0) {
                System.out.print(numbers[i] + " ");
            }
        }
        System.out.println(); // Imprimir nueva línea
    }

    private static int random() {
        int min = 1;
        int max = 10;
        return (int) (Math.random() * (max - min + 1)) + min;
    }
}